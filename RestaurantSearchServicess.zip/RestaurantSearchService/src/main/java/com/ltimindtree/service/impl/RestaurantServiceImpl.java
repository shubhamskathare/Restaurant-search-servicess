package com.ltimindtree.service.impl;



import java.util.List;

import org.apache.kafka.clients.admin.NewTopic;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.kafka.support.KafkaHeaders;
import org.springframework.messaging.Message;
import org.springframework.messaging.support.MessageBuilder;
import org.springframework.stereotype.Service;

import com.ltimindtree.dto.OrderEvent;
import com.ltimindtree.entity.Restaurant;
import com.ltimindtree.exception.ResourceNotFoundException;
import com.ltimindtree.repository.RestaurantRepository;
import com.ltimindtree.service.RestaurantService;

@Service
public class RestaurantServiceImpl implements RestaurantService{
	
	@Autowired
	private RestaurantRepository restaurantRepository;

	@Override
	public Restaurant createRestaurant(Restaurant restaurant) {
		// TODO Auto-generated method stub
		return restaurantRepository.save(restaurant);
	}

	@Override
	public List<Restaurant> getRestaurantByName(String name){
		// TODO Auto-generated method stub
		return restaurantRepository.findByName(name);
	}

	@Override
	public List<Restaurant> getRestaurantByLocation(String location) {
		// TODO Auto-generated method stub
		return restaurantRepository.findByLocation(location);
	}

	@Override
	public List<Restaurant> getRestaurantByDistance(int distance) {
		// TODO Auto-generated method stub
		return restaurantRepository.findByDistance(distance);
	}

	@Override
	public List<Restaurant> getRestaurantByCuisine(String cuisine) {
		// TODO Auto-generated method stub
		return restaurantRepository.findByCuisine(cuisine);
	}

	@Override
	public List<Restaurant> getRestaurantByBudget(int budget) {
		// TODO Auto-generated method stub
		return restaurantRepository.findByBudget(budget);
	}

	@Override
	public List<Restaurant> getRestaurantByRatings(double rating) {
		// TODO Auto-generated method stub
		return restaurantRepository.findByRatings(rating);
	}
	
	private static final Logger logger= LoggerFactory.getLogger(RestaurantServiceImpl.class);
	
	@Autowired
	private NewTopic topic;
	 
	@Autowired
	private KafkaTemplate<String, OrderEvent> kafkaTemplate;

	/*
	 * public RestaurantServiceImpl(NewTopic topic, KafkaTemplate<String,
	 * OrderEvent> kafkaTemplate) { super(); this.topic = topic; this.kafkaTemplate
	 * = kafkaTemplate; }
	 */
	
	public void sendMessage(OrderEvent event) {
		logger.info(String.format("Order even => %s", event.toString()));
		
		//create message
		Message<OrderEvent> message=MessageBuilder.withPayload(event).setHeader(KafkaHeaders.TOPIC, topic.name()).build();
		kafkaTemplate.send(message);
	}

	

}
