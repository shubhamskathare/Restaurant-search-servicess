package com.ltimindtree.service;

import java.util.List;

import com.ltimindtree.entity.MenuItem;

public interface MenuItemService {
	
	public List<MenuItem> findAllByRestaurantIdAndName(String restaurantId,String name);
	public List<MenuItem> findByName(String name);
	public MenuItem createRestaurantMenu(MenuItem menu);
	List<MenuItem> findAllMenusByRestaurantId(String restaurantId);
	

}
