package com.ltimindtree.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ltimindtree.entity.MenuItem;
import com.ltimindtree.repository.MenuItemRepository;
import com.ltimindtree.service.MenuItemService;

@Service
public class MenuItemServiceImpl implements MenuItemService{
	
	@Autowired
	private MenuItemRepository menuRepository;

	@Override
	public List<MenuItem> findAllByRestaurantIdAndName(String restaurantId, String name) {
		// TODO Auto-generated method stub
		return menuRepository.findAllByRestaurantIdAndName(restaurantId, name);
	}

	@Override
	public List<MenuItem> findByName(String name) {
		// TODO Auto-generated method stub
		return menuRepository.findByName(name);
	}

	@Override
	public MenuItem createRestaurantMenu(MenuItem menu) {
		// TODO Auto-generated method stub
		return menuRepository.save(menu);
	}

	@Override
	public List<MenuItem> findAllMenusByRestaurantId(String restaurantId) {
		// TODO Auto-generated method stub
		return menuRepository.findAllMenuByRestaurantId(restaurantId);
	}

}
