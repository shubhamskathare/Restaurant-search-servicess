package com.ltimindtree.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.ltimindtree.entity.MenuItem;

@Repository
public interface MenuItemRepository extends JpaRepository<MenuItem, Integer>{
	
	public List<MenuItem> findAllMenuByRestaurantId(String restaurantId);
	public List<MenuItem> findAllByRestaurantIdAndName(String restaurantId, String name);
	public List<MenuItem> findByName(String name);
	

}
